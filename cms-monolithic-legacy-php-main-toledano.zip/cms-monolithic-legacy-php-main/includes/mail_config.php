<?php
// Mail configuration and helper to send email via Mailtrap (supports STARTTLS)
// Configure these values from your Mailtrap sandbox
define('MAIL_HOST', 'sandbox.smtp.mailtrap.io');
define('MAIL_PORT', 587); // Use 587 with STARTTLS for better compatibility
define('MAIL_USER', '901445a6739ffb'); // Correct username from Mailtrap inbox
define('MAIL_PASS', '3e97a98246322a');
define('MAIL_FROM_EMAIL', 'no-reply@example.com');
define('MAIL_FROM_NAME', 'CMS Shop');

/**
 * Send an HTML email via SMTP using STARTTLS (Mailtrap)
 * Returns true on success or an error string on failure.
 */
function send_email_mailtrap($to, $subject, $html_body, $from = MAIL_FROM_EMAIL, $from_name = MAIL_FROM_NAME) {
    $host = MAIL_HOST;
    $port = MAIL_PORT;
    $user = MAIL_USER;
    $pass = MAIL_PASS;

    $timeout = 30;
    $errno = 0; $errstr = '';
    $log = "--- SMTP Dialog (mail_config) at " . date('c') . " ---\n";

    $remote = "tcp://{$host}:{$port}";
    $fp = @stream_socket_client($remote, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT);
    if (!$fp) {
        $log .= "ERROR: Unable to connect to {$remote} - {$errstr} ({$errno})\n";
        file_put_contents(__DIR__ . '/../smtp_debug.log', $log, FILE_APPEND);
        return "Connection failed: {$errstr} ({$errno})";
    }

    $read = function() use ($fp, &$log) {
        $data = '';
        while ($str = fgets($fp, 515)) {
            $data .= $str;
            $log .= "S: " . rtrim($str, "\r\n") . "\n";
            if (isset($str[3]) && substr($str, 3, 1) == ' ') break;
        }
        return $data;
    };

    $write = function($cmd) use ($fp, &$log) {
        $log .= "C: " . $cmd . "\n";
        fputs($fp, $cmd . "\r\n");
        return true;
    };

    // Read greeting
    $read();

    // EHLO
    $write('EHLO localhost'); $read();

    // Try STARTTLS
    $write('STARTTLS');
    $resp = $read();
    if (strpos($resp, '220') === false) {
        // STARTTLS may be optional; proceed without TLS if server doesn't support it
        $log .= "INFO: STARTTLS not supported or failed, continuing without TLS. Response: " . trim($resp) . "\n";
    } else {
        // enable crypto
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            $log .= "ERROR: Failed to enable TLS\n";
            file_put_contents(__DIR__ . '/../smtp_debug.log', $log, FILE_APPEND);
            fclose($fp);
            return "Failed to enable TLS";
        }
        // EHLO again after TLS
        $write('EHLO localhost'); $read();
    }

    // AUTH LOGIN
    $write('AUTH LOGIN'); $read();
    $write(base64_encode($user)); $read();
    $write(base64_encode($pass)); $resp = $read();
    if (strpos($resp, '235') === false && strpos($resp, '235') === false) {
        $log .= "ERROR: Authentication failed. Response: " . trim($resp) . "\n";
        file_put_contents(__DIR__ . '/../smtp_debug.log', $log, FILE_APPEND);
        fclose($fp);
        return "Authentication failed";
    }

    // MAIL FROM / RCPT TO
    $write('MAIL FROM: <' . $from . '>'); $read();
    $write('RCPT TO: <' . $to . '>'); $rcpt = $read();
    if (strpos($rcpt, '250') === false && strpos($rcpt, '251') === false) {
        $log .= "ERROR: RCPT TO rejected. Response: " . trim($rcpt) . "\n";
        file_put_contents(__DIR__ . '/../smtp_debug.log', $log, FILE_APPEND);
        fclose($fp);
        return "Recipient rejected";
    }

    $write('DATA'); $read();

    $headers  = "From: {$from_name} <{$from}>\r\n";
    $headers .= "To: {$to}\r\n";
    $headers .= "Subject: {$subject}\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "\r\n";

    $message = $headers . $html_body . "\r\n.";
    $write($message);
    $read();

    $write('QUIT'); $read();
    fclose($fp);

    $log .= "--- End dialog ---\n\n";
    file_put_contents(__DIR__ . '/../smtp_debug.log', $log, FILE_APPEND);
    return true;
}

?>