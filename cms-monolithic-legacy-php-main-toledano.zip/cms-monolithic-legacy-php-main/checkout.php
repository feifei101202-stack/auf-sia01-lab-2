<?php

include "includes/db.php";
/* Page Header and navigation */
include "includes/header.php";
include "includes/navigation.php";
require_once __DIR__ . '/admin/includes/ecommerce/Order.php';
require_once __DIR__ . '/admin/includes/ecommerce/OrderItem.php';
require_once __DIR__ . '/includes/mail_config.php';

$order_created = false;
$error_message = '';
$order_id = null;
$order_total = 0;
$order_items = [];

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        $error_message = 'Please log in to proceed with checkout.';
        throw new Exception($error_message);
    }

    // Check if cart exists and is not empty
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        $error_message = 'Your cart is empty.';
        throw new Exception($error_message);
    }

    $cart = $_SESSION['cart'];

    // Calculate total amount
    $total_amount = 0;
    foreach ($cart as $item) {
        $total_amount += ($item['price'] * $item['quantity']);
    }

    // Create order
    $order = new Order($connection);
    $order->create(
        $_SESSION['user_id'],
        $total_amount,
        'pending'
    );

    $order_id = $order->getOrderId();

    // Create order items and update product stock
    foreach ($cart as $item) {
        $orderItem = new OrderItem($connection);
        $orderItem->create(
            $order_id,
            $item['product_id'],
            $item['quantity'],
            $item['price']
        );
        $order_items[] = $item;

        // Decrease product stock quantity
        $product_id = intval($item['product_id']);
        $quantity_ordered = intval($item['quantity']);
        $update_stock_query = "UPDATE products SET stock_quantity = stock_quantity - {$quantity_ordered} WHERE product_id = {$product_id}";
        mysqli_query($connection, $update_stock_query);
    }

    $order_total = $total_amount;
    $order_created = true;

    // Fetch customer info for email
    $customer_email = '';
    $customer_name = '';
    $user_id = intval($_SESSION['user_id']);
    $user_q = mysqli_query($connection, "SELECT user_firstname, user_lastname, user_email FROM users WHERE user_id = {$user_id} LIMIT 1");
    if ($user_q && $user_row = mysqli_fetch_assoc($user_q)) {
        $customer_name = trim($user_row['user_firstname'] . ' ' . $user_row['user_lastname']);
        $customer_email = $user_row['user_email'];
    }

    // Prepare and send order confirmation email via SMTP (Mailtrap sandbox)
    if (!empty($customer_email)) {
        // Mailtrap SMTP credentials (sandbox) - now using mail_config.php
        $smtp_host = MAIL_HOST;
        $smtp_port = MAIL_PORT;
        $smtp_user = MAIL_USER;
        $smtp_pass = MAIL_PASS;

        // Build email
        $subject = "Order Confirmation - #{$order_id}";
        $from_email = 'no-reply@example.com';
        $from_name = 'CMS Shop';

        $html = "<h2>Thank you for your order, " . htmlspecialchars($customer_name) . "</h2>";
        $html .= "<p><strong>Order ID:</strong> #" . htmlspecialchars($order_id) . "</p>";
        $html .= "<p><strong>Order Date:</strong> " . date('F j, Y, g:i a') . "</p>";
        $html .= "<p><strong>Total:</strong> $" . number_format($order_total, 2) . "</p>";
        $html .= "<h4>Items</h4>";
        $html .= "<table border='1' cellpadding='6' cellspacing='0' style='border-collapse:collapse;'>";
        $html .= "<thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead><tbody>";
        foreach ($order_items as $it) {
            $subtotal = $it['price'] * $it['quantity'];
            $html .= "<tr>";
            $html .= "<td>" . htmlspecialchars($it['name']) . "</td>";
            $html .= "<td>$" . number_format($it['price'], 2) . "</td>";
            $html .= "<td>" . intval($it['quantity']) . "</td>";
            $html .= "<td>$" . number_format($subtotal, 2) . "</td>";
            $html .= "</tr>";
        }
        $html .= "</tbody></table>";

        // Lightweight SMTP send using fsockopen with dialog logging for debugging
        $send_smtp = function($host, $port, $user, $pass, $from, $to, $subject, $html_body, $from_name = '') use ($order_id) {
            $timeout = 30;
            $errno = 0; $errstr = '';
            $dialog = "--- SMTP Dialog for order {$order_id} at " . date('c') . " ---\n";
            $fp = fsockopen($host, $port, $errno, $errstr, $timeout);
            if (!$fp) {
                $dialog .= "ERROR: Could not connect to SMTP host: $errstr ($errno)\n";
                file_put_contents(__DIR__ . '/smtp_debug.log', $dialog, FILE_APPEND);
                return "Could not connect to SMTP host: $errstr ($errno)";
            }

            $read = function() use ($fp, &$dialog) {
                $data = '';
                while ($str = fgets($fp, 515)) {
                    $data .= $str;
                    $dialog .= "S: " . rtrim($str, "\r\n") . "\n";
                    if (isset($str[3]) && substr($str, 3, 1) == ' ') break;
                }
                return $data;
            };

            $write = function($cmd) use ($fp, &$dialog) {
                $dialog .= "C: " . $cmd . "\n";
                fputs($fp, $cmd . "\r\n");
                return true;
            };

            // Read server greeting
            $resp = $read();

            $write("EHLO localhost"); $resp = $read();
            $write("AUTH LOGIN"); $resp = $read();
            $write(base64_encode($user)); $resp = $read();
            $write(base64_encode($pass)); $resp = $read();
            $write("MAIL FROM: <{$from}>"); $resp = $read();
            $write("RCPT TO: <{$to}>"); $resp = $read();
            $write("DATA"); $resp = $read();

            $headers  = "From: {$from_name} <{$from}>\r\n";
            $headers .= "To: {$to}\r\n";
            $headers .= "Subject: {$subject}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $headers .= "\r\n";

            $message = $headers . $html_body . "\r\n.";
            $write($message);
            $resp = $read();
            $write("QUIT");
            $resp = $read();
            fclose($fp);

            $dialog .= "--- End of dialog ---\n\n";
            // Append to debug log
            file_put_contents(__DIR__ . '/smtp_debug.log', $dialog, FILE_APPEND);
            return true;
        };

        // First try the STARTTLS-capable helper in includes/mail_config.php
        if (function_exists('send_email_mailtrap')) {
            $result = send_email_mailtrap($customer_email, $subject, $html, $from_email, $from_name);
            if ($result !== true) {
                error_log('Mailtrap helper failed: ' . $result);
                // fallback to the simpler fsockopen sender
                $smtp_result = $send_smtp($smtp_host, $smtp_port, $smtp_user, $smtp_pass, $from_email, $customer_email, $subject, $html, $from_name);
                if ($smtp_result !== true) {
                    error_log('Fallback SMTP send failed: ' . $smtp_result);
                }
            }
        } else {
            $smtp_result = $send_smtp($smtp_host, $smtp_port, $smtp_user, $smtp_pass, $from_email, $customer_email, $subject, $html, $from_name);
            if ($smtp_result !== true) {
                error_log('SMTP send failed: ' . $smtp_result);
            }
        }
    }

    // Clear cart after successful order
    unset($_SESSION['cart']);

} catch (Exception $e) {
    $error_message = $e->getMessage();
}
?>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <?php if ($order_created && $order_id) { ?>
                <!-- Order Confirmation -->
                <div class="alert alert-success">
                    <h1 class="page-header">
                        <i class="glyphicon glyphicon-ok-circle"></i> Order Confirmed!
                    </h1>
                </div>

                <div class="panel panel-success">
                    <div class="panel-heading">
                        <h3 class="panel-title">Order Details</h3>
                    </div>
                    <div class="panel-body">
                        <p><strong>Order ID:</strong> #<?php echo htmlspecialchars($order_id); ?></p>
                        <p><strong>Order Date:</strong> <?php echo date('F j, Y, g:i a'); ?></p>
                        <p><strong>Status:</strong> <span class="label label-info">Pending</span></p>
                        <p><strong>Total Amount:</strong> <span class="text-success"><strong>$<?php echo number_format($order_total, 2); ?></strong></span></p>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Order Items</h3>
                    </div>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order_items as $item) { 
                                $subtotal = $item['price'] * $item['quantity'];
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                    <td>$<?php echo number_format($subtotal, 2); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

                <div class="alert alert-info">
                    <h4>Thank You!</h4>
                    <p>Your order has been successfully created. We will process your order soon and send you a confirmation email.</p>
                    <p>You can view your orders in your account profile.</p>
                </div>

                <div class="form-group">
                    <a href="shop.php" class="btn btn-primary">
                        <span class="glyphicon glyphicon-shopping-cart"></span> Continue Shopping
                    </a>
                    <a href="index.php" class="btn btn-default">
                        <span class="glyphicon glyphicon-home"></span> Go to Home
                    </a>
                </div>

            <?php } else { ?>
                <!-- Error Message -->
                <div class="alert alert-danger">
                    <h1 class="page-header">
                        <i class="glyphicon glyphicon-exclamation-sign"></i> Checkout Error
                    </h1>
                </div>

                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <h3 class="panel-title">Error Details</h3>
                    </div>
                    <div class="panel-body">
                        <p><?php echo htmlspecialchars($error_message); ?></p>
                    </div>
                </div>

                <div class="form-group">
                    <?php if (!isset($_SESSION['user_id'])) { ?>
                        <a href="registration.php" class="btn btn-primary">
                            <span class="glyphicon glyphicon-user"></span> Login / Register
                        </a>
                    <?php } ?>
                    <a href="shop.php" class="btn btn-default">
                        <span class="glyphicon glyphicon-shopping-cart"></span> Back to Shop
                    </a>
                </div>

            <?php } ?>
        </div>

        <?php
        include "includes/sidebar.php"
        ?>
    </div>
    <!-- /.row -->

    <hr>
    <?php
    /* Page Footer */
    include "includes/footer.php"
    ?>
</div>