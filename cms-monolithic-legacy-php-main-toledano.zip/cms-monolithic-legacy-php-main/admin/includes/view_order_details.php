<?php
include "./includes/ecommerce/Order.php";
include "./includes/ecommerce/OrderItem.php";
include "./includes/ecommerce/Product.php";

// Check if order_id is provided
if (!isset($_GET['order_id'])) {
    echo "<div class='alert alert-danger'>Order ID is missing.</div>";
    echo "<a href='orders.php' class='btn btn-default'>Back to Orders</a>";
    exit;
}

$order_id = intval($_GET['order_id']);

// Fetch order details
$order = new Order($connection);
$order_result = $order->find($order_id);

if (!$order_result || mysqli_num_rows($order_result) == 0) {
    echo "<div class='alert alert-danger'>Order not found.</div>";
    echo "<a href='orders.php' class='btn btn-default'>Back to Orders</a>";
    exit;
}

$order_row = mysqli_fetch_assoc($order_result);
$user_id = $order_row['user_id'];
$total_amount = $order_row['total_amount'];
$order_date = $order_row['order_date'];
$status = $order_row['status'];

// Fetch customer information
$customer_name = 'Unknown';
$customer_email = '';
$customer_phone = '';
$user_query = mysqli_query($connection, "SELECT user_firstname, user_lastname, user_email FROM users WHERE user_id = {$user_id} LIMIT 1");
if ($user_query && $user_row = mysqli_fetch_assoc($user_query)) {
    $customer_name = trim($user_row['user_firstname'] . ' ' . $user_row['user_lastname']);
    $customer_email = $user_row['user_email'];
}

// Fetch order items
$orderItem = new OrderItem($connection);
$items_result = $orderItem->getByOrderId($order_id);
?>

<div class="row">
    <div class="col-md-12">
        <a href="orders.php" class="btn btn-default">
            <span class="glyphicon glyphicon-arrow-left"></span> Back to Orders
        </a>
    </div>
</div>

<hr>

<!-- Order Information -->
<div class="row">
    <div class="col-md-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Order #<?php echo htmlspecialchars($order_id); ?></h3>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Order Date:</strong> <?php echo htmlspecialchars($order_date); ?></p>
                        <p><strong>Total Amount:</strong> <span class="text-success"><strong>$<?php echo number_format($total_amount, 2); ?></strong></span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Status:</strong> <span class="label label-info"><?php echo htmlspecialchars($status); ?></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Customer Information -->
    <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
                <h3 class="panel-title">Customer Information</h3>
            </div>
            <div class="panel-body">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($customer_name); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($customer_email); ?></p>
                <p><strong>User ID:</strong> <?php echo htmlspecialchars($user_id); ?></p>
            </div>
        </div>
    </div>
</div>

<hr>

<!-- Order Items -->
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Order Items</h3>
            </div>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($items_result && mysqli_num_rows($items_result) > 0) {
                        while ($item_row = mysqli_fetch_assoc($items_result)) {
                            $product_id = $item_row['product_id'];
                            $quantity = $item_row['quantity'];
                            $price = $item_row['price'];
                            $subtotal = $price * $quantity;

                            // Fetch product name
                            $product_query = mysqli_query($connection, "SELECT name FROM products WHERE product_id = {$product_id} LIMIT 1");
                            $product_name = 'Unknown';
                            if ($product_query && $product_row = mysqli_fetch_assoc($product_query)) {
                                $product_name = $product_row['name'];
                            }

                            echo "<tr>
                                    <td>" . htmlspecialchars($product_id) . "</td>
                                    <td>" . htmlspecialchars($product_name) . "</td>
                                    <td>$" . number_format($price, 2) . "</td>
                                    <td>" . htmlspecialchars($quantity) . "</td>
                                    <td>$" . number_format($subtotal, 2) . "</td>
                                </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>No items in this order.</td></tr>";
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4" style="text-align: right;">Order Total:</th>
                        <th>$<?php echo number_format($total_amount, 2); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
