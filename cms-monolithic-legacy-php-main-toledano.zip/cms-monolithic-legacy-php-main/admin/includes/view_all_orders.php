<?php
include "./includes/ecommerce/Order.php";
include "./includes/ecommerce/OrderItem.php";
include "./includes/ecommerce/Product.php";

?>

<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Order ID</th>
            <th>User ID</th>
            <th>Customer Name</th>
            <th>Total Amount</th>
            <th>Order Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $order = new Order($connection);
        $all_orders = $order->all();
        while ($row = mysqli_fetch_assoc($all_orders)) {

            $order_id = $row['order_id'];
            $user_id = $row['user_id'];
            $customer = $row['customer'] ?? 'N/A';
            $total_amount = $row['total_amount'];
            $order_date = $row['order_date'];
            $status = $row['status'];

            echo "<tr>
                    <td><strong>#" . htmlspecialchars($order_id) . "</strong></td>
                    <td>" . htmlspecialchars($user_id) . "</td>
                    <td>" . htmlspecialchars($customer) . "</td>
                    <td>$" . number_format($total_amount, 2) . "</td>
                    <td>" . htmlspecialchars($order_date) . "</td>
                    <td><span class='label label-info'>" . htmlspecialchars($status) . "</span></td>
                    <td>
                        <a href='orders.php?source=view_order_details&order_id=" . htmlspecialchars($order_id) . "' class='btn btn-sm btn-primary'>
                            <span class='glyphicon glyphicon-eye-open'></span> View Details
                        </a>
                    </td>
                </tr>";
        }
        ?>
    </tbody>
</table>
