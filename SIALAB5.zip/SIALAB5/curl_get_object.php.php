<?php


$objectId = 1;


$url = "https://api.restful-api.dev/objects/" . $objectId;


$ch = curl_init();




curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPGET, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);


$response = curl_exec($ch);


if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die("cURL Error: " . $error);
}


$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);


curl_close($ch);


header("Content-Type: application/json");


echo json_encode([
    "http_status" => $httpCode,
    "object" => json_decode($response, true)
], JSON_PRETTY_PRINT);
?>
