<?php


$objectId = "PASTE_REAL_ID_HERE";




$url = "https://api.restful-api.dev/objects/" . $objectId;




$ch = curl_init($url);




curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
curl_setopt($ch, CURLOPT_TIMEOUT, 30);




$response = curl_exec($ch);




if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die("cURL Error: " . $error);
}




$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);




curl_close($ch);




header("Content-Type: application/json");


echo json_encode([
    "http_status" => $httpCode,
    "response" => $response ?: "No content returned"
], JSON_PRETTY_PRINT);
