<?php


$invalidId = 99999999;




$url = "https://api.restful-api.dev/objects/" . $invalidId;




$ch = curl_init($url);




curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPGET, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);




$response = curl_exec($ch);


if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die("cURL Error: " . $error);
}




$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);


curl_close($ch);




header("Content-Type: application/json");


echo json_encode([
    "http_status" => $httpCode,
    "message" => $httpCode === 200 ? json_decode($response, true) : "Error: Object not found",
    "api_response" => json_decode($response, true)
], JSON_PRETTY_PRINT);


