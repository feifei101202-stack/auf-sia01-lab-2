<?php


$url = "https://api.restful-api.dev/objects";


$ch = curl_init($url);


curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_HTTPGET, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);




$response = curl_exec($ch);




if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die("cURL Error: " . $error);
}




$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);




$headers = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);


$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);


curl_close($ch);


echo "HTTP Status Code: " . $httpCode . PHP_EOL . PHP_EOL;
echo "Response Headers:" . PHP_EOL;
echo $headers . PHP_EOL;
echo "Response Body:" . PHP_EOL;
echo $body;
