<?php


$url = "https://api.restful-api.dev/objects";




$data = [
    "name" => "AUF Student Laptop",
    "data" => [
        "brand" => "Apple",
        "ram" => "32GB",
        "storage" => "1TB SSD"
    ]
];




$ch = curl_init($url);




curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_TIMEOUT, 30);


$response = curl_exec($ch);


if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die("cURL Error: " . $error);
}


$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);


curl_close($ch);


header("Content-Type: application/json");


echo json_encode([
    "http_status" => $httpCode,
    "response" => json_decode($response, true)
], JSON_PRETTY_PRINT);


